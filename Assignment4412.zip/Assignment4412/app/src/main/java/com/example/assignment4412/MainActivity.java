package com.example.assignment4412;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerContacts;
    private List<Contact> contacts;
    private ContactAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerContacts = findViewById(R.id.recyclerContacts);

        contacts = new ArrayList<>();

        contacts.add(new Contact(R.drawable.ic_whatsapp, "Video Call", "+92 300 1234567"));
        contacts.add(new Contact(R.drawable.ic_whatsapp, "Voice Call", "+92 300 1234567"));
        contacts.add(new Contact(R.drawable.ic_whatsapp, "Message", "+92 300 1234567"));

        adapter = new ContactAdapter(MainActivity.this, contacts);
        recyclerContacts.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menus, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menuFavourite:
                Toast.makeText(this, "Favourites", Toast.LENGTH_SHORT).show();
                break;

            case R.id.menuSettings:
                Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show();
                break;

            case R.id.menuExit:
                onBackPressed();
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        MaterialAlertDialogBuilder alertDialogBuilder = new MaterialAlertDialogBuilder(MainActivity.this);
        alertDialogBuilder.setTitle("Close Application");
        alertDialogBuilder.setMessage("Do you really want to close this App?");
        alertDialogBuilder.setCancelable(true);
        alertDialogBuilder.setNeutralButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        alertDialogBuilder.create().show();
    }
}