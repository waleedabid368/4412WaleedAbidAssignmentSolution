package com.example.assignment4412;

public class Contact {
    private int resID;
    private String category;
    private String number;

    public Contact(int resID, String category, String number) {
        this.resID = resID;
        this.category = category;
        this.number = number;
    }

    public int getResID() {
        return resID;
    }

    public void setResID(int resID) {
        this.resID = resID;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}